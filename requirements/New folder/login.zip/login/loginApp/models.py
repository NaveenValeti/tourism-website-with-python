from django.db import models
import bcrypt
import re

# Create your models here.

class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        duplicateEmail = User.objects.filter(email_address = postData['email'])
        # add keys and values to errors dictionary for each invalid field
        if len(postData['fname']) == 0:
            errors["fnameReq"] = "First name required"
        if len(postData['lname']) == 0:
            errors["lnameReq"] = "Last name required"
        if len(postData['email']) == 0:
            errors["emailReq"] = "Email Address required"
        elif not EMAIL_REGEX.match(postData['email']):
            errors['validEmail'] = "Invalid email address"
        elif len(duplicateEmail) > 0:
            errors['taken'] = "There is already and account associated with that email address"
        if len(postData['pw']) == 0:
            errors["pwReq"] = "Password required"
        elif len(postData['pw']) < 3:
            errors["pwLen"] = "Password must be 8 characters or more"
        return errors

    def login_validator(self, postData):
        errors = {}
        duplicateEmail = User.objects.filter(email_address = postData['email'])
        if len(duplicateEmail) == 0:
            errors['emailNotFound'] = "Email address not found. Please register as New User."
        else:
            # if duplicateEmail[0].password != postData['pw']:
            #     errors['wrongPassword'] = "Password is incorrect."
            if not bcrypt.checkpw(postData['pw'].encode(), duplicateEmail[0].password.encode()):
                errors['wrongPassword'] = "Password is incorrect."
        return errors

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email_address = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()